import os
import sys
from tqdm import tqdm

root_dir = "../../"

sys.path.append(root_dir)

from dataset import RSNADataset

data_dir = os.path.join(root_dir, "data")

train_wl = RSNADataset(
    data_dir=data_dir, op="train", augment=False, weak_supervision=True
)
train_wl_positive_count = 0
train_wl_negative_count = 0
for series_obj in tqdm(train_wl.series_dictionary.values()):
    target = int(series_obj["target"])
    if target == 1:
        train_wl_positive_count += 1
    else:
        train_wl_negative_count += 1
print(
    f"WL, train: {train_wl_positive_count + train_wl_negative_count} total, {train_wl_positive_count} positive, {train_wl_negative_count} negative"
)


val_wl = RSNADataset(
    data_dir=data_dir, op="val", augment=False, weak_supervision=True
)
val_wl_positive_count = 0
val_wl_negative_count = 0
for series_obj in tqdm(val_wl.series_dictionary.values()):
    target = int(series_obj["target"])
    if target == 1:
        val_wl_positive_count += 1
    else:
        val_wl_negative_count += 1
print(
    f"WL, val: {val_wl_positive_count + val_wl_negative_count} total, {val_wl_positive_count} positive, {val_wl_negative_count} negative"
)

train_sl = RSNADataset(
    data_dir=data_dir, op="train", augment=False, weak_supervision=False
)
train_sl_positive_count = 0
train_sl_negative_count = 0
for image_data in tqdm(train_sl.images):
    target = int(image_data[1])
    if target == 1:
        train_sl_positive_count += 1
    else:
        train_sl_negative_count += 1
print(
    f"SL, train: {train_sl_positive_count + train_sl_negative_count} total, {train_sl_positive_count} positive, {train_sl_negative_count} negative"
)

val_sl = RSNADataset(
    data_dir=data_dir, op="val", augment=False, weak_supervision=False
)
val_sl_positive_count = 0
val_sl_negative_count = 0
for image_data in tqdm(val_sl.images):
    target = int(image_data[1])
    if target == 1:
        val_sl_positive_count += 1
    else:
        val_sl_negative_count += 1
print(
    f"SL, val: {val_sl_positive_count + val_sl_negative_count} total, {val_sl_positive_count} positive, {val_sl_negative_count} negative"
)
