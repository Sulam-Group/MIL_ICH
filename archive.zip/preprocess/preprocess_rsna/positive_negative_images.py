import os
import json
from tqdm import tqdm

root_dir = "../"
data_dir = os.path.join(root_dir, "data")

ops = ["train", "val"]
for op in ops:
    op_series = os.path.join(data_dir, f"{op}_series.json")
    op_positive_images = os.path.join(data_dir, f"{op}_positive_images.json")
    op_negative_images = os.path.join(data_dir, f"{op}_negative_images.json")
    with open(op_series, "r") as f:
        series = json.load(f)
    positive_images = []
    negative_images = []
    for data in tqdm(series.values()):
        images = data["series"]
        for image_data in images:
            image_id, label = image_data
            if int(label) == 1:
                positive_images.append(image_id)
            else:
                negative_images.append(image_id)
    with open(op_positive_images, "w") as f:
        json.dump(positive_images, f)
    with open(op_negative_images, "w") as f:
        json.dump(negative_images, f)
