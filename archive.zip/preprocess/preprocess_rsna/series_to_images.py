import os
import json
from random import shuffle
from tqdm import tqdm

data_dir = "../data"
splits = ["train", "val"]

for split in splits:
    split_images = []
    split_series_path = os.path.join(data_dir, f"{split}_series.json")
    split_images_path = os.path.join(data_dir, f"{split}_images.json")
    with open(split_series_path, "r") as f, open(split_images_path, "w") as r:
        split_series = json.load(f)
        for serie_id, series in tqdm(split_series.items()):
            series_images = series["series"]
            split_images.extend(series_images)
        shuffle(split_images)
        json.dump(split_images, r)