import os
import sys
import numpy as np
import torch
from joblib import Parallel, delayed
from torch.utils.data import DataLoader
from tqdm import tqdm

root_dir = "../"
sys.path.append(root_dir)

from dataset import RSNADataset

data_dir = os.path.join(root_dir, "data")

dataset = RSNADataset(
    data_dir=data_dir,
    op="train",
    augment=False,
    weak_supervision=False,
    m=None,
)
dataloader = DataLoader(dataset, batch_size=1, num_workers=12, shuffle=False)

bad_images = []
for i, data in enumerate(tqdm(dataloader)):
    if data:
        bad_images.append(i)
print(bad_images)
