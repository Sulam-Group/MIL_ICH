import os
import json
from tqdm import tqdm

root_dir = "../"
data_dir = os.path.join(root_dir, "data")

op = "train"
with open(os.path.join(data_dir, f"{op}_series.json"), "r") as f:
    series = json.load(f)
positive_images_pool = {}
negative_images_pool = {}
for data in tqdm(series.values()):
    target = int(data["target"])
    images = data["series"]
    for image_id, image_label in images:
        image_label = int(image_label)
        if target:
            positive_images_pool[image_id] = image_label
        else:
            negative_images_pool[image_id] = image_label
with open(os.path.join(data_dir, f"{op}_positive_images.json"), "r") as f:
    positive_images = json.load(f)
    assert all([positive_images_pool[image_id] for image_id in positive_images])
assert all([not v for v in negative_images_pool.values()])
with open(
    os.path.join(data_dir, f"{op}_positive_images_pool.json"), "w"
) as positive_pool_f, open(
    os.path.join(data_dir, f"{op}_negative_images_pool.json"), "w"
) as negative_pool_f:
    json.dump(positive_images_pool, positive_pool_f)
    json.dump(negative_images_pool, negative_pool_f)
