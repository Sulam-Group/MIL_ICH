import os
import json
from tqdm import tqdm
from azure.storage.blob import ContainerClient

conn_string = "DefaultEndpointsProtocol=https;AccountName=hemdetectionstorage;AccountKey=KGqUS40Nqb7I0rvLrbn6iOnG0+W8F7VF4czOMvmqVNm+9IhY9JisLfRN4nU2c0Ebs3coIU71+cq+m6499MbN/w==;EndpointSuffix=core.windows.net"
container_client = ContainerClient.from_connection_string(
    conn_str=conn_string, container_name="datasets"
)

root_dir = "../"
data_dir = os.path.join(root_dir, "data")
image_dir = os.path.join(data_dir, "images")

with open(os.path.join(data_dir, "val_images.json"), "r", encoding="utf-8") as f:
    val_images = json.load(f)

for i, val_image_data in enumerate(tqdm(val_images)):
    val_image_id, _ = val_image_data
    try:
        assert os.path.exists(os.path.join(image_dir, f"ID_{val_image_id}.npy"))
        container_client.delete_blob(
            f"rsna-intracranial-hemorrhage-sampler/images/ID_{val_image_id}.npy"
        )
    except:
        print(f"Failed {val_image_id}")
