import sys
import os
import numpy as np
from tqdm import tqdm

root_dir = "../"
data_dir = os.path.join(root_dir, "data")
sys.path.append(root_dir)

from _dataset import HemorrhageDataset

ops = ["train", "val"]
for op in ops:
    dataset = HemorrhageDataset(data_dir=data_dir, op=op, augment=False)
    for idx in tqdm(range(len(dataset))):
        series_idx = dataset.series_ids[idx]
        series_obj = dataset.series_dictionary[series_idx]

        series = np.array(series_obj["series"])
        zcoords = [dataset.__zcoord__(image) for image in series[:, 0]]
        sorted_idx = np.argsort(zcoords)

        np.save(
            os.path.join(data_dir, "series", f"{series_idx}_sorted_ids.npy"), sorted_idx
        )
