import os
import json
from tqdm import tqdm
from azure.storage.blob import ContainerClient

conn_string = "DefaultEndpointsProtocol=https;AccountName=hemdetectionstorage;AccountKey=KGqUS40Nqb7I0rvLrbn6iOnG0+W8F7VF4czOMvmqVNm+9IhY9JisLfRN4nU2c0Ebs3coIU71+cq+m6499MbN/w==;EndpointSuffix=core.windows.net"
container_client = ContainerClient.from_connection_string(
    conn_str=conn_string, container_name="datasets"
)

root_dir = "../"
data_dir = os.path.join(root_dir, "data")
series_dir = os.path.join(data_dir, "series")

with open(os.path.join(data_dir, "train_series.json"), "r", encoding="utf-8") as f:
    val_series_dictionary = json.load(f)
val_series_ids = list(val_series_dictionary.keys())

for series_id in tqdm(val_series_ids):
    try:
        with open(os.path.join(series_dir, series_id), "rb") as data:
            container_client.upload_blob(
                name=f"rsna-intracranial-hemorrhage-sampler/series/{series_id}",
                data=data,
            )
    except Exception as e:
        print(f"Failed {series_id}, {e}")
