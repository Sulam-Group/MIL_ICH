import os
import numpy as np
from pydicom import dcmread
from pydicom.multival import MultiValue
from joblib import Parallel, delayed
from tqdm import tqdm

root_dir = "../../"
data_dir = os.path.join(root_dir, "data")
rsna_dir = os.path.join(data_dir, "RSNA")
dicom_dir = os.path.join(rsna_dir, "stage_2_train")


def preprocess(img, **kvargs):
    slope = kvargs["slope"]
    intercept = kvargs["intercept"]
    img = img * slope + intercept
    return img


def preprocess_and_save(image):
    img_id = image.split(".")[0]
    out_path = os.path.join(dicom_dir, f"{img_id}.npy")
    # read DICOM image
    ds = dcmread(os.path.join(dicom_dir, image))
    # read DICOM window properties
    window_metadata = {
        "intercept": ds.RescaleIntercept,
        "slope": ds.RescaleSlope,
    }
    window_metadata = {
        k: int(u[0]) if type(u) == MultiValue else int(u)
        for k, u in window_metadata.items()
    }
    try:
        # extract pixel values (Hounsfield)
        img = ds.pixel_array
        # preprocess image
        img = preprocess(img, **window_metadata)
        assert type(img) is not np.uint16
        # save HU image
        np.save(out_path, img, allow_pickle=True)
    except:
        print(f"Failed {image}")


images = os.listdir(dicom_dir)
images = list(filter(lambda x: ".dcm" in x, images))
Parallel(n_jobs=-1)(delayed(preprocess_and_save)(image) for image in tqdm(images))
