import os
import json
import numpy as np
from azure.storage.blob import ContainerClient
from tqdm import tqdm

conn_string = "DefaultEndpointsProtocol=https;AccountName=hemdetectionstorage;AccountKey=KGqUS40Nqb7I0rvLrbn6iOnG0+W8F7VF4czOMvmqVNm+9IhY9JisLfRN4nU2c0Ebs3coIU71+cq+m6499MbN/w==;EndpointSuffix=core.windows.net"
container_client = ContainerClient.from_connection_string(
    conn_str=conn_string, container_name="datasets"
)

root_dir = "../"
data_dir = os.path.join(root_dir, "data")
dicom_dir = os.path.join(data_dir, "stage_2_train")

with open(
    os.path.join(data_dir, "train_positive_images_pool.json"), "r"
) as positive_images_f, open(
    os.path.join(data_dir, "train_negative_images_pool.json"), "r"
) as negative_images_f:
    positive_images_dictionary = json.load(positive_images_f)
    negative_images_dictionary = json.load(negative_images_f)

positive_images = list(positive_images_dictionary.keys())
negative_images = list(negative_images_dictionary.keys())
images = positive_images + negative_images
for image_id in tqdm(images):
    with open(os.path.join(dicom_dir, f"ID_{image_id}.npy"), "rb") as image:
        container_client.upload_blob(
            name=f"rsna-intracranial-hemorrhage-sampler/images/{image_id}.npy",
            data=image,
            overwrite=True,
        )
