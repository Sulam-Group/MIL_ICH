import os
import pandas as pd

root_dir = "../../"
data_dir = os.path.join(root_dir, "data")
cq500_dir = os.path.join(data_dir, "cq500")

series_df = pd.read_csv(
    os.path.join(cq500_dir, "exams_to_series.csv"), index_col="name"
)
thick_series = series_df[series_df["slice_thickness"] >= 3]
lowercase_series_dir = thick_series["series_dir"].str.lower()
plain_thick_series = thick_series[
    (~lowercase_series_dir.str.contains("contrast"))
    & (thick_series["length"] <= 70)
    & (thick_series["length"] >= 10)
]
plain_thick_series.to_csv(os.path.join(cq500_dir, "plain_thick_series.csv"), index=True)
