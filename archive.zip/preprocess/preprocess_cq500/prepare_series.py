import os
import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

root_dir = "../"
data_dir = os.path.join(root_dir, "data")
cq500_dir = os.path.join(data_dir, "cq500")
image_dir = os.path.join(cq500_dir, "images")
os.makedirs(os.path.join(cq500_dir, "series"), exist_ok=True)

plain_thick_series_df = pd.read_csv(os.path.join(cq500_dir, "plain_thick_series.csv"))

for _, row in tqdm(plain_thick_series_df.iterrows()):
    series_id = row["series_id"]
    exam_dir = row["exam_dir"]
    series_dir = row["series_dir"]
    series_image_dir = os.path.join(image_dir, exam_dir, series_dir)
    series_images = os.listdir(series_image_dir)
    series_images = list(
        filter(lambda f: "sorted_ids" not in f and ".npy" in f, series_images)
    )
    print(series_images)
    series = [np.load(os.path.join(series_image_dir, f)) for f in series_images]
    series = torch.tensor(series)
    break
    # torch.save(series, os.path.join(cq500_dir, "series", series_id))
