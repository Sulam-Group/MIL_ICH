import os
import sys
import numpy as np
from tqdm import tqdm

root_dir = "../../"

sys.path.append(root_dir)

from dataset import CQ500Dataset

data_dir = os.path.join(root_dir, "data")
cq500_dir = os.path.join(data_dir, "cq500")

dataset = CQ500Dataset(data_dir=cq500_dir)

positive_count = 0
negative_count = 0
image_count = 0
for _, series in tqdm(dataset.plain_thick_series_df.iterrows()):
    target = int(series["global_label"])
    if target == 1:
        positive_count += 1
    else:
        negative_count += 1

    exam_dir = series["exam_dir"]
    series_dir = series["series_dir"]
    sorted_ids = np.load(
        os.path.join(dataset.image_dir, exam_dir, series_dir, "sorted_ids.npy")
    )
    image_count += len(sorted_ids)

print(
    f"CQ500, {positive_count + negative_count} total, {positive_count} positive, {negative_count} negative, {image_count} images"
)
