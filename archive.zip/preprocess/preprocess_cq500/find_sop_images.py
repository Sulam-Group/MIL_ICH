import os
import sys
import pandas as pd
import numpy as np
from torch.utils.data import DataLoader
from tqdm import tqdm

root_dir = "../../"
sys.path.append(root_dir)

from dataset import CQ500Dataset

data_dir = os.path.join(root_dir, "data")
cq500_dir = os.path.join(data_dir, "cq500")
image_dir = os.path.join(cq500_dir, "images")

plain_thick_series_df = pd.read_csv(os.path.join(cq500_dir, "plain_thick_series.csv"))
dataset = CQ500Dataset(cq500_dir)
dataloader = DataLoader(
    dataset,
    batch_size=1,
    shuffle=False,
    num_workers=4,
    pin_memory=True,
)

image_sops = {
    "1.2.276.0.7230010.3.1.4.296485376.1.1521713007.1700822",
    "1.2.276.0.7230010.3.1.4.296485376.1.1521713021.1704518",
    "1.2.276.0.7230010.3.1.4.296485376.1.1521713469.1816851",
    "1.2.276.0.7230010.3.1.4.296485376.1.1521713940.1946656",
}
for series_idx, _ in enumerate(tqdm(dataloader)):
    series_row = plain_thick_series_df.iloc[series_idx]
    exam_dir = series_row["exam_dir"]
    series_dir = series_row["series_dir"]
    sorted_ids = np.load(
        os.path.join(image_dir, exam_dir, series_dir, "sorted_ids.npy")
    )
    sop_ids = np.load(os.path.join(image_dir, exam_dir, series_dir, "sop_ids.npy"))
    sop_ids = sop_ids[sorted_ids]
    for img_name, sop_id in sop_ids:
        if sop_id in image_sops:
            image_sops.remove(sop_id)
            print(sop_id, exam_dir, series_dir, img_name)
    if len(image_sops) == 0:
        break
