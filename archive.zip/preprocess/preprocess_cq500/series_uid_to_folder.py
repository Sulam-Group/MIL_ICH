import os
import re
import json
import pandas as pd
from pydicom import dcmread
from tqdm import tqdm

root_dir = "../../"
data_dir = os.path.join(root_dir, "data")
cq500_dir = os.path.join(data_dir, "cq500")

read_df = pd.read_csv(os.path.join(cq500_dir, "reads.csv"))
read_df.set_index("name", inplace=True)

# predictions_df = pd.read_csv(os.path.join(cq500_dir, "prediction_probabilities.csv"))
# predictions_df = predictions_df.set_index("name")
# hemorrhage_column_names = ["ICH", "IPH", "IVH", "SDH", "EDH", "SAH"]
# predictions_df = predictions_df[hemorrhage_column_names]

exam_dirs = [
    name
    for name in os.listdir(cq500_dir)
    if os.path.isdir(os.path.join(cq500_dir, name)) and "CQ500" in name
]
assert len(exam_dirs) == 490

exams = []
for exam_dir in tqdm(exam_dirs):
    for dirname, series_dirs, _ in os.walk(
        os.path.join(cq500_dir, exam_dir, "Unknown Study")
    ):
        for series_dir in series_dirs:
            for _, _, files in os.walk(os.path.join(dirname, series_dir)):
                slices = list(filter(lambda x: x.endswith(".dcm"), files))
                ds = dcmread(os.path.join(dirname, series_dir, slices[0]))
                series_id = ds["SeriesInstanceUID"].value
                slice_thickness = ds["SliceThickness"].value
                exam_dir_name = exam_dir.split(" ")[0]
                exam_number = int(re.search("CQ500CT(\d+)", exam_dir_name).group(1))
                exam_name = f"CQ500-CT-{exam_number}"
                exam_read = read_df.loc[exam_name][
                    [f"R{i}:ICH" for i in range(1, 4)]
                ].tolist()
                global_label = sum(exam_read) > 1
                exams.append(
                    {
                        "name": exam_name,
                        "series_id": series_id,
                        "global_label": global_label,
                        "exam_dir": exam_dir,
                        "series_dir": series_dir,
                        "slice_thickness": slice_thickness,
                        "length": len(slices),
                    }
                )

exams_df = pd.DataFrame(exams).set_index("name")
exams_df.to_csv(os.path.join(cq500_dir, "exams_to_series.csv"))
