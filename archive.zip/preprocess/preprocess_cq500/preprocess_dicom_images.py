import os
import pandas as pd
import numpy as np
from pydicom import dcmread
from pydicom.multival import MultiValue
from tqdm import tqdm

root_dir = "../"
data_dir = os.path.join(root_dir, "data")
cq500_dir = os.path.join(data_dir, "cq500")
image_dir = os.path.join(cq500_dir, "images")
os.makedirs(image_dir, exist_ok=True)

preprocess = lambda img, intercept, slope: img * slope + intercept

plain_thick_series_df = pd.read_csv(os.path.join(cq500_dir, "plain_thick_series.csv"))

for _, row in tqdm(plain_thick_series_df.iterrows()):
    exam_dir = row["exam_dir"]
    series_dir = row["series_dir"]
    series_image_dir = os.path.join(image_dir, exam_dir, series_dir)
    os.makedirs(series_image_dir, exist_ok=True)
    for _, _, files in os.walk(
        os.path.join(cq500_dir, exam_dir, "Unknown Study", series_dir)
    ):
        slices = list(filter(lambda f: f.endswith(".dcm"), files))
        zcoords = []
        sop_ids = []
        for slice in slices:
            ds = dcmread(
                os.path.join(cq500_dir, exam_dir, "Unknown Study", series_dir, slice)
            )

            img = ds.pixel_array
            sop_id = ds.SOPInstanceUID
            intercept = ds.RescaleIntercept
            slope = ds.RescaleSlope
            zcoord = ds[0x20, 0x32].value[-1]
            zcoords.append(zcoord)
            sop_ids.append((slice, sop_id))
            intercept = (
                int(intercept[0])
                if isinstance(intercept, MultiValue)
                else int(intercept)
            )
            slope = int(slope[0]) if isinstance(slope, MultiValue) else int(slope)
            img = preprocess(img, intercept, slope)
            # np.save(os.path.join(series_image_dir, slice.replace(".dcm", ".npy")), img)

        sorted_ids = np.argsort(zcoords)
        np.save(os.path.join(series_image_dir, "sorted_ids.npy"), sorted_ids)
        np.save(os.path.join(series_image_dir, "sop_ids.npy"), sop_ids)

        # if "CT C" in series_dir:
        #     print(len(slices))
