import os
import nibabel as nib
import numpy as np
import torch
from tqdm import tqdm

root_dir = "../"
data_dir = os.path.join(root_dir, "data")
ctich_dir = os.path.join(data_dir, "ct_ich")
scan_dir = os.path.join(ctich_dir, "ct_scans")

image_dir = os.path.join(ctich_dir, "images")
os.makedirs(image_dir, exist_ok=True)
series_dir = os.path.join(ctich_dir, "series")
os.makedirs(series_dir, exist_ok=True)

series_files = os.listdir(scan_dir)
series_files = filter(lambda x: x.endswith(".nii"), series_files)
# print(list(series_files))
for series_file in tqdm(series_files):
    patient_id = series_file.split(".")[0]
    series_nifti = nib.load(os.path.join(scan_dir, series_file))
    series = np.asarray(series_nifti.dataobj)
    series = np.transpose(series, (2, 1, 0))
    for i, image in enumerate(series):
        np.save(os.path.join(image_dir, f"{patient_id}_{i}.npy"), image)
    series = torch.from_numpy(series)
    torch.save(series, os.path.join(series_dir, patient_id))
