import os
import pandas as pd
import numpy as np
import nibabel as nib
from skimage import measure
from tqdm import tqdm

root_dir = "../../"

data_dir = os.path.join(root_dir, "data")
ctich_dir = os.path.join(data_dir, "ct_ich")
mask_dir = os.path.join(ctich_dir, "masks")

annotation_df = []
for file in tqdm(os.listdir(mask_dir)):
    if ".nii" not in file:
        continue

    patient_number = int(file.split(".")[0].lstrip("0"))

    mask_nifti = nib.load(os.path.join(mask_dir, file))
    mask = np.asarray(mask_nifti.dataobj, dtype=int)
    mask = np.transpose(mask, (2, 1, 0))

    for i in range(mask.shape[0]):
        slice_mask = mask[i, :, :].squeeze()

        conn_c, num_conn_c = measure.label(slice_mask, connectivity=2, return_num=True)
        for j in range(1, num_conn_c + 1):
            row, column = (conn_c == j).nonzero()
            row_min = np.min(row)
            column_min = np.min(column)

            height = np.max(row) - row_min
            width = np.max(column) - column_min

            if height > 0 and width > 0:
                annotation_df.append(
                    {
                        "PatientNumber": patient_number,
                        "SliceNumber": i + 1,
                        "data": {
                            "x": column_min,
                            "y": row_min,
                            "height": height,
                            "width": width,
                        },
                    }
                )

annotation_df = pd.DataFrame(annotation_df)
annotation_df.set_index(["PatientNumber", "SliceNumber"], inplace=True)
annotation_df.to_csv(os.path.join(ctich_dir, "annotations.csv"))
