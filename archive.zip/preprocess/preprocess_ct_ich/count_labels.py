import os
import sys
import numpy as np
from tqdm import tqdm

root_dir = "../../"

sys.path.append(root_dir)

from dataset import CTICHDataset

data_dir = os.path.join(root_dir, "data")
ctich_dir = os.path.join(data_dir, "ct_ich")

dataset = CTICHDataset(data_dir=ctich_dir)

positive_count = 0
negative_count = 0
image_count = 0
for data in tqdm(dataset):
    series, target, labels = data
    if target == 1:
        positive_count += 1
    else:
        negative_count += 1
    image_count += len(labels)

print(
    f"CQ500, {positive_count + negative_count} total, {positive_count} positive, {negative_count} negative, {image_count} images"
)
