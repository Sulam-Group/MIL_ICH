library("reticulate")
library("pROC")

os <- import("os")
np <- import("numpy")

dataset <- "cq500"
data_dir <- os$path$join(dataset)

target <- np$load(os$path$join(data_dir, "global_target.npy"))
wl_prediction <- np$load(os$path$join(data_dir, "wl_global_prediction.npy"))
sl_prediction <- np$load(os$path$join(data_dir, "sl_global_prediction.npy"))

wl_roc <- roc(target, wl_prediction)
sl_roc <- roc(target, sl_prediction)

print(wl_roc)
print(sl_roc)

delong_test <- roc.test(
    wl_roc,
    sl_roc,
    method = "delong",
    alternative = "greater",
)

print(delong_test)